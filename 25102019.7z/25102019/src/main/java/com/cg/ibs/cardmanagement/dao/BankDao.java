package com.cg.ibs.cardmanagement.dao;

public interface BankDao {

}

package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;

import java.text.SimpleDateFormat;

import java.time.LocalDateTime;

import java.util.Date;

import java.util.Random;

import java.util.regex.Matcher;
import java.util.regex.Pattern;



import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;

import com.cg.ibs.cardmanagement.bean.CustomerBean;

import com.cg.ibs.cardmanagement.dao.CaseIdDao;
import com.cg.ibs.cardmanagement.dao.CaseIdDaoImpl;
import com.cg.ibs.cardmanagement.dao.CustomerDao;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.dao.CustomerDaoImpl;

public class CustomerServiceImpl implements CustomerService {

	CaseIdDao caseIdDao = new CaseIdDaoImpl();

	public void getCardLength(BigInteger card) throws IBSException {
		int length = card.toString().length();
		if (length != 16)
			throw new IBSException(ErrorMessages.INC_LENGTH_PIN_MESSAGE);

	}

	CustomerDao customerDao;

	public CustomerServiceImpl() {
		customerDao = new CustomerDaoImpl();

	}

	CaseIdBean caseIdObj = new CaseIdBean();
	CustomerBean customObj = new CustomerBean();
	AccountBean accountObj = new AccountBean();
	Random random = new Random();

	String caseIdGenOne = " ";
	static String caseIdTotal = " ";
	static int caseIdGenTwo = 0;
	LocalDateTime timestamp;
	LocalDateTime fromDate;
	LocalDateTime toDate;
	static String setCardType = null;
	static String uniqueID = null;
	static String customerReferenceID = null;

	@Override
	public String addToServiceRequestTable(String caseIdGenOne) {
		Date dNow = new Date();
		SimpleDateFormat ftDateFormat = new SimpleDateFormat("yyMMddhhmmssS");
		String dateString = ftDateFormat.format(dNow);

		caseIdTotal = caseIdGenOne + dateString;

		return caseIdTotal;
	}

	public String getNewCardtype(int newCardType) throws IBSException {
		String cardType = newCardType + "";
		Pattern pattern = Pattern.compile("[123]");
		Matcher matcher = pattern.matcher(cardType);
		if (!(matcher.find() && matcher.group().equals(cardType)))
			throw new IBSException(ErrorMessages.INVALID_INPUT_MESSAGE);

		switch (newCardType) {
		case 1:

			setCardType = "Platinum";
			break;
		case 2:
			setCardType = "Gold";
			break;
		case 3:
			setCardType = "Silver";
			break;

		}
		return setCardType;
	}



	@Override
	public int getPinLength(String pin) throws IBSException {
		int count = pin.length();

		if (count != 4)
			throw new IBSException(ErrorMessages.INC_LENGTH_PIN_MESSAGE);
		return count;
	}

	@Override
	public String viewServiceRequestStatus(String customerReferenceId) throws IBSException {
		CaseIdBean caseIdObj = new CaseIdBean();
		caseIdObj.setCustomerReferenceId(customerReferenceId);

		String currentServiceRequestStatus = caseIdDao.getCustomerReferenceStatus(caseIdObj, customerReferenceId);
		if (currentServiceRequestStatus == null)
			throw new IBSException(ErrorMessages.INVALID_TRANSACTION_ID_MESSAGE);

		return currentServiceRequestStatus;

	}

	@Override
	public String checkMyChoice(int myChoice) throws IBSException {
		String cardType = myChoice + "";
		Pattern pattern = Pattern.compile("[12]");
		Matcher matcher = pattern.matcher(cardType);
		if (!(matcher.find() && matcher.group().equals(cardType)))
			throw new IBSException(ErrorMessages.INVALID_CHOICE_MESSAGE);

		switch (myChoice) {
		case 1:
			setCardType = "Gold";
			break;
		case 2:
			setCardType = "Platinum";
			break;

		}
		return setCardType;

	}

	@Override
	public String checkMyChoiceGold(int myChoice) throws IBSException {
		String cardType = myChoice + "";
		Pattern pattern = Pattern.compile("[2]");
		Matcher matcher = pattern.matcher(cardType);
		if (!(matcher.find() && matcher.group().equals(cardType)))
			throw new IBSException(ErrorMessages.INVALID_CHOICE_MESSAGE);
		return ("Platinum");
	}

	@Override
	public void checkDays(int days1) throws IBSException {
		if (days1 < 1) {

			throw new IBSException(ErrorMessages.LESS_DAYS_MESSAGE);

		} else if (days1 >= 730) {

			throw new IBSException(ErrorMessages.MORE_DAYS_MESSAGE);
		}

	}

	@Override
	public boolean verifyUci(BigInteger uci) throws IBSException {
		String suci = uci.toString();
		Pattern pattern = Pattern.compile("[0-9]{16}");
		Matcher matcher = pattern.matcher(suci);
		if (!(matcher.find() && matcher.group().equals(suci)))
			throw new IBSException(ErrorMessages.INC_LENGTH_UCI_MESSAGE);
		boolean check1 = customerDao.verifyUCI(uci);
		if (!check1)
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		return (check1);
	}

}
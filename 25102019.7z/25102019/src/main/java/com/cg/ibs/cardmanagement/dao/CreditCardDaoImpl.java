package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardStatus;
import com.cg.ibs.cardmanagement.bean.CustomerBean;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CreditCardDaoImpl implements CreditCardDao {

	private EntityManager entityManager;
	private EntityTransaction entityTransaction;

	public CreditCardDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
		entityTransaction = JpaUtilImpl.getTransaction();
	}

	public List<CreditCardBean> viewAllCreditCards() throws IBSException {

		TypedQuery<CreditCardBean> creditQuery = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_CREDIT_CARD,
				CreditCardBean.class);
		List<CreditCardBean> creditCards = creditQuery.getResultList();

		return creditCards;

	}

	@Override
	public boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException {
		boolean result = false;

		CreditCardBean d = entityManager.find(CreditCardBean.class, creditCardNumber);

		if (d != null)
			result = true;

		return result;
	}

	@Override
	public void setNewCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException {
		CreditCardBean cardBean = entityManager.find(CreditCardBean.class, creditCardNumber);
		cardBean.setCurrentPin(newPin);

	}

	@Override
	public String getCreditCardPin(BigInteger creditCardNumber) throws IBSException {

		TypedQuery<String> query = entityManager
                .createQuery("select c.currentPin from CreditCardBean c where cardNumber=:creditCardNum", String.class);
        query.setParameter("creditCardNum", creditCardNumber);
        String pin = null;
        try{
            pin = query.getSingleResult();
        }
        catch(NoResultException e){
            throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
        }
        return pin;
	}

	@Override
	public BigInteger getCreditUci(BigInteger creditCardNumber) throws IBSException {
		
		BigInteger uci=null;
		try {
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"select d.UCI from CreditCardBean c join  c. customerBeanObject d where c.cardNumber=:creditCardNum",
				BigInteger.class);
		query.setParameter("creditCardNum", creditCardNumber);
uci=query.getSingleResult();
		}
		catch(NoResultException e) {
			   throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE); 
		}
		return uci ;

	}

	@Override
	public String getcreditCardType(BigInteger creditCardNumber) throws IBSException {

		TypedQuery<String> query = entityManager
                .createQuery("select c.cardType from CreditCardBean c where c.cardNumber=:creditCardNum", String.class);
        query.setParameter("creditCardNum", creditCardNumber);

 

        String type = null;
        try{
          type = query.getSingleResult();
        }
        catch(NoResultException e){
            throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
        }
        return type;
	}

	@Override
	public CreditCardStatus getCreditCardStatus(BigInteger creditCardNumber) throws IBSException {
		TypedQuery<CreditCardStatus> query = entityManager.createQuery(
                "select d.cardStatus from CreditCardBean d where d.cardNumber=:creditCardNum", CreditCardStatus.class);
        query.setParameter("creditCardNum", creditCardNumber);
        CreditCardStatus status = null;
        try{
            status = query.getSingleResult();
        }
        catch(NoResultException e){
            throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
        }
        return status;
	}

	@Override
	public void actionANCC(CreditCardBean bean1) throws IBSException {

		entityTransaction.begin();
		entityManager.persist(bean1);
		entityTransaction.commit();

	}

	@Override
	public void actionBlockCC(String queryId, CreditCardStatus status) throws IBSException {

		TypedQuery<BigInteger> query = entityManager
				.createQuery("select d.cardNumber from CaseIdBean d where d.caseIdTotal =:queryid", BigInteger.class);
		query.setParameter("queryid", queryId);
		BigInteger cardnum = query.getSingleResult();
		CreditCardBean cardBean = entityManager.find(CreditCardBean.class, cardnum);
		cardBean.setCardStatus(status);

	}

	@Override
	public void actionUpgradeCC(String queryId) throws IBSException {
		TypedQuery<CaseIdBean> query = entityManager
				.createQuery("select d from CaseIdBean d where d.caseIdTotal =:queryid", CaseIdBean.class);
		query.setParameter("queryid", queryId);
		CaseIdBean caseIdBean = query.getSingleResult();
		BigInteger cardNum = caseIdBean.getCardNumber();
		String type = caseIdBean.getDefineServiceRequest();
		CreditCardBean cardBean = entityManager.find(CreditCardBean.class, cardNum);
		cardBean.setCardType(type);

	}

}

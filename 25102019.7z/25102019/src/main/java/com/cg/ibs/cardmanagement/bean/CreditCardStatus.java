package com.cg.ibs.cardmanagement.bean;

public enum CreditCardStatus {

		 APPROVED, DECLINED, PENDING
		
}
